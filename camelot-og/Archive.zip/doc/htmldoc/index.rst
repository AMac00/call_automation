Welcome
=======

Camelot-pi is a python based Camelot VAPI client.

Table Of Contents
=================
.. toctree::
   :maxdepth: 10

   installation
   getting_started
   api_reference
   people

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
