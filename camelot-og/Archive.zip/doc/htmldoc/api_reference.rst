*************
API Reference
*************

Here you may find reference documentation for the :mod:`camelot` and APIs. 

.. toctree::
   :maxdepth: 3
   :glob:

   api/*
