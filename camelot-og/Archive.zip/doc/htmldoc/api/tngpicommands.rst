**************************************
Camelot raw and simulated endpoint API
**************************************

This document is for simulated endpoint or creation of raw message.
only when tng-pi is used these methods can be used.(not for camelot-pi only scripts)

-----------
API Methods
-----------

.. automodule:: camelot.utils.rawendpoint_helper
    :members:
    :undoc-members:
    :show-inheritance:

