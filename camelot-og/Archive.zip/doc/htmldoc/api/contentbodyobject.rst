************************************************************************
ContentBodyObject API
************************************************************************

The ContentBodyObject contains content body associated with
SipMessage object .

------------------------------------------------------------------------
API Methods
------------------------------------------------------------------------
.. autoclass:: camelot.vapi.vapi_endpoint_query_control.ContentBodyObject
   :members:
