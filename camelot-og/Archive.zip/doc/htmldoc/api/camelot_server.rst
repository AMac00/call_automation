******************
Camelot Server API
******************

The Camelot Server API provides the ability to probe and get the Camelot generic functionalities.

-----------
API Methods
-----------

.. autoclass:: camelot.camelot_server.CamelotServer
    :members:
    :show-inheritance:
