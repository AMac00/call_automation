***********
BCG API
***********

The BCG API provides the ability to perform BCG functionalities.

-----------------------
Starting the BCG Server
-----------------------

bcgserver.py  [--host|-h <hostname/ip>] [--port|-p <port>]


-----------
API Methods
-----------

.. automodule:: camelot.bcg
    :members:
    :show-inheritance:
    
