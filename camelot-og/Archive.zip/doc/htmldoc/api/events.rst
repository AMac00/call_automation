************
Events API
************

The Event Classes

.. automodule:: camelot.events
    :members:
    :undoc-members:
    :show-inheritance:
