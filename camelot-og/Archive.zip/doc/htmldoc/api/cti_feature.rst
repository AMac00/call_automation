************
CTI feature API
************

The CTI feature API provides CSFD endpoint specific functionalities.

-----------
API Methods
-----------

.. autoclass:: camelot.vapi.vapi_cti_feature.CamelotCTIFeature
    :members:
