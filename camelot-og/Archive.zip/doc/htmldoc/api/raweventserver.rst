*********************
Raw events server API
*********************

This document is for simulated endpoint or creation of raw message.
only when tng-pi is used these methods can be used.(not for camelot-pi only scripts)

-----------
API Methods
-----------
.. automethod:: camelot.tngdevice.camelot_server.CamelotServer.create_out_action_set
.. automethod:: camelot.tngdevice.camelot_server.CamelotServer.create_in_action_set
